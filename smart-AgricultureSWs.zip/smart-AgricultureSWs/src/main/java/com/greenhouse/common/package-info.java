/**
 * 公共类层 - 通用工具和常量
 * 包含统一返回结果、异常处理等公共类
 */
package com.greenhouse.common;