/**
 * 实体类层 - 数据库表对应的实体类
 * 包含所有数据库表对应的Java实体类
 */
package com.greenhouse.entity;