/**
 * 数据访问层 - MyBatis Mapper接口
 * 包含所有数据库操作的Mapper接口
 */
package com.greenhouse.mapper;