/**
 * 业务服务层 - 处理业务逻辑
 * 包含所有业务服务接口和实现类
 */
package com.greenhouse.service;