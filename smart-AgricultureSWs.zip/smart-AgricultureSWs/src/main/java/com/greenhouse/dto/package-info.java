/**
 * 数据传输对象层 - DTO类
 * 包含用于前后端数据传输的DTO类
 */
package com.greenhouse.dto;