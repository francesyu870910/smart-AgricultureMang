/**
 * 控制器层 - 处理HTTP请求和响应
 * 包含所有REST API控制器类
 */
package com.greenhouse.controller;